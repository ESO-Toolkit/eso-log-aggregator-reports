/** <Typesetter>.getTransferables **/

troikaDefine(
function getTransferables(e){let t=[];for(let n in e)e[n]&&e[n].buffer&&t.push(e[n].buffer);return t}
)