/** <Typr Font Parser>.init **/

troikaDefine(
function init(e,t,n){return n(e(),t())}
)