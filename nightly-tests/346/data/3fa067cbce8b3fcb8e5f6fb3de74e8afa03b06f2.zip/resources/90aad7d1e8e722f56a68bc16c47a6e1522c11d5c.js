/** <Typesetter>.init **/

troikaDefine(
function init(e){return function(t){return new Promise(n=>{e.typeset(t,n)})}}
)