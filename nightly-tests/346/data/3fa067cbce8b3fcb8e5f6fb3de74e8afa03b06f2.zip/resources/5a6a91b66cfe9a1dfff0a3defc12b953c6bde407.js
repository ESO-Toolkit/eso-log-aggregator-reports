/** <FontResolver>.init **/

troikaDefine(
function init(e,t,n){return e(t,n())}
)